<style>
.glow {
  font-size: 80px;
  color: #fff;
  text-align: center;
  -webkit-animation: glow 1s ease-in-out infinite alternate;

}

@-webkit-keyframes glow {
  from {
    text-shadow: 0 0 10px #fff, 0 0 20px #fff, 0 0 30px #e60073, 0 0 40px #e60073, 0 0 50px #e60073, 0 0 60px #e60073, 0 0 70px #e60073;
  }

  to {
    text-shadow: 0 0 20px #fff, 0 0 30px #ff4da6, 0 0 40px #ff4da6, 0 0 50px #ff4da6, 0 0 60px #ff4da6, 0 0 70px #ff4da6, 0 0 80px #ff4da6;
  }
}
</style>
 <footer class="site-footer">
      <div class="container">
        

        
        <div class="row text-center">
          <div class="col-md-12">
            <p style = "font-size : 30pt ; color : #FF0000 ; font-weight : bold">

            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All Rights Reserved
                <span style = "color : brown">|</span>
                <span style = "color : #006400">This website is made with <i class="fas fa-heart icon-heart text-warning"></i> by </span><a class= "glow" href="#" target="_blank">Sourabh Dewangan</a>

            </p>
          </div>
          
        </div>
      </div>
    </footer>